﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NetworkCommsDotNet;

namespace client
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Client client = new Client();
                client.run();
            }
            catch (Exception e)
            {
                Console.WriteLine("Error: " + e.Message);
                Console.ReadKey(true);
                Console.WriteLine("Press any key to close the client");
                NetworkComms.Shutdown();
            }
        }
    }
}
