﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common;
using NetworkCommsDotNet;
using NetworkCommsDotNet.Connections;
using NetworkCommsDotNet.Connections.TCP;

namespace client
{
    class Client
    {
        public Player Player;
        private NetworkUser NetUser;
        private Game Game;

        public Client()
        {
            initCallbacks();
            requireConnection();
        }

        void requireConnection()
        {
            Console.WriteLine("Please enter your coinche favorite IP and Port in the format 100.100.100.100:100 and press enter:");
            string serverInfo = Console.ReadLine();
            //string serverIp = serverInfo.Substring(0, serverInfo.LastIndexOf(":")); //debug
            //UInt16 serverPort = UInt16.Parse(serverInfo.Split(':').Last()); //debug
            string serverIp = "192.168.0.82"; //debug

            UInt16 serverPort = 2000; //debug

            NetUser = new NetworkUser(null, serverIp, serverPort);
            
            NetworkComms.SendObject("Connection", serverIp, serverPort, "Asking for connection");
        }

        void initCallbacks()
        {
            NetworkComms.AppendGlobalIncomingPacketHandler<string>("200", confirmationHandler);
            NetworkComms.AppendGlobalIncomingPacketHandler<string>("500", errorHandler);
            NetworkComms.AppendGlobalIncomingPacketHandler<Player>("Start", startGame);
            NetworkComms.AppendGlobalIncomingUnmanagedPacketHandler(unknownHandler);
            NetworkComms.AppendGlobalIncomingPacketHandler<Component<Bet>>("Bet", receivedBet);
        }

        private void receivedBet(PacketHeader header, Connection connection, Component<Bet> comp)
        {
            Game.receivedBet(comp.Object);
        }

        private static void confirmationHandler(PacketHeader header, Connection connection, string message)
        {
            Console.WriteLine("Connection OK");
        }

        private static void errorHandler(PacketHeader header, Connection connection, string message)
        {
            Console.WriteLine("Connection KO " + message);
            NetworkComms.Shutdown();
            System.Environment.Exit(84);
        }

        private void unknownHandler(PacketHeader packetHeader, Connection connection, byte[] message)
        {
            Console.WriteLine("Unknown packet received: " + message);
        }

        public void startGame(PacketHeader header, Connection connection, Player player)
        {
            Console.WriteLine("Start received");
            Player = player;
            Player.setNetworkUser(NetUser);
            Game = new Game(Player, connection);
        }

        public void run()
        {
            while (true)
            {
                Console.ReadKey(true);
            }
        }
    }
}
