﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common;
using NetworkCommsDotNet;
using NetworkCommsDotNet.Connections;
using NetworkCommsDotNet.Connections.TCP;

namespace client
{
    public class Game
    {
        public Bet Bet { get; private set; }
        private string[] SignsName = { "Clubs", "Spades", "Hearts", "Diamonds" }; //♣♠♥♦
        private Player Player;
        private Connection serverInfos;
        private string serverIp;
        private UInt16 serverPort;

        public Game(Player player, Connection serverDatas)
        {
            Player = player;

            string endPoint = serverDatas.ConnectionInfo.RemoteEndPoint.ToString();
            serverIp = endPoint.Split(':').First();
            serverPort = UInt16.Parse(endPoint.Split(':').Last());

            serverInfos = TCPConnection.GetConnection(new ConnectionInfo(serverIp, serverPort));

            serverInfos.SendObject<Component<string>>("Ready", new Component<string>(player.RoomHash, player.Id.ToString()));
        }

        public void receiveBet(Bet bet)
        {
            if (bet.PlayerId == 0)
            {
                Console.WriteLine("\nThere is no current bet");
            }
            else
            {
                Console.WriteLine("Current bet: Trump is " + SignsName[bet.AtoutSign]
                    + " and value is " + bet.BetValue
                    + " from player " + bet.PlayerId);
            }
            Bet = bet;
            if (bet.CurrentPlayerId != Player.Id)
            {
                Console.WriteLine("It's player " + bet.CurrentPlayerId + " turn to bet");
                //    if (bet.PlayerId != (Player.Id + 2) % 4 && bet.PlayerId != 0) //Si le bet n'appartient pas a notre groupe
                //    {
                //        Console.WriteLine("You can coinche the actual bet");
                //        Console.WriteLine("Other commands: pass");
                //        bet = Console.ReadLine(); //cette commande doit etre placee dans une boucle en mode non bloquant au cas ou notre tour vient a arriver
                //    }
            }
            else if (bet.CurrentPlayerId == Player.Id)
            {
                string newBet = askBet();
                bool isDone = treatBet(newBet);
                if (isDone == false)
                {
                    sendBet(newBet);
                }
            }
        }

        private bool isAGoodSign(string bet)
        {
            int value;

            if (!int.TryParse(bet.Split('/').First(), out value) || value < 0 || value >= 4)
            {
                Console.WriteLine("Wrong sign");
                return (false);
            }
            return (true);
        }

        private bool isAGoodValue(string bet)
        {
            UInt16 value;

            if (!UInt16.TryParse(bet.Split('/').Last(), out value) || value < 80 || value > 160)
            {
                Console.WriteLine("Wrong value");
                return (false);
            }
            return (true);
        }

        private bool canCoinche()
        {
            return (Bet.BetValue != 0 && Bet.PlayerId != Player.Id && Bet.PlayerId != (Player.Id + 2) % 4 && !Bet.Coinche); //Le bet n'est fait ni par nous ni par un allie
        }

        private bool specialCommand(string bet)
        {
            if (bet == "pass")// || (bet == "coinche" && canCoinche() == true) || (bet == "surcoinche" && Bet.Coinche))
            {
                return (true);
            }
            return (false);
        }

        public string askBet()
        {
            Console.WriteLine("It's your turn for the bet");
            string bet;
            do
            {
                Console.WriteLine("\nBet format: Signs/Value");
                Console.WriteLine("Signs: (0: {0}, 1: {1}, 2: {2}, 3: {3})", SignsName[0], SignsName[1], SignsName[2], SignsName[3]);
                Console.WriteLine("Value has to be between 80 and 160");
                Console.WriteLine("Other commands: pass");// / coinche / surcoinche");
                bet = Console.ReadLine();
            } while (specialCommand(bet) == false && (isAGoodSign(bet) == false || isAGoodValue(bet) == false));
            return (bet);
        }

        private void sendPass(string bet)
        {
            serverInfos.SendObject<Component<string>>("PassBet", new Component<string>(Player.RoomHash, bet));
        }

        private void sendCoinche()
        {
            //to implem
        }

        private void sendSurcoinche()
        {
            //to implem
        }

        private bool treatBet(string bet)
        {
            bool isDone = true;

            if ((Bet.Coinche = (bet == "coinche")))
            {
                //sendCoinche();//to implem
            }
            else if ((Bet.Coinche = (bet == "pass")))
            {
                sendPass(bet);
            }
            else if ((Bet.Coinche = (bet == "surcoinche")))
            {
                //sendSurcoinche();//to implem
            }
            else
            {
                isDone = false;
            }

            return (isDone);
        }

        private void sendBet(string bet)
        {
            Console.WriteLine("\nSending bet");
            serverInfos.SendObject<Component<string>>("Bet", new Component<string>(Player.RoomHash, bet));
        }
    }
}
