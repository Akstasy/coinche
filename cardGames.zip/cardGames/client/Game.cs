﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common;
using NetworkCommsDotNet;
using NetworkCommsDotNet.Connections;

namespace client
{
    public class Game
    {
        public Bet Bet { get; private set; }
        private string[] SignsName = { "Clubs", "Spades", "Hearts", "Diamonds" }; //♣♠♥♦
        private Player Player;
        private Connection serverInfos;
        private string serverIp;
        private UInt16 serverPort;

        public Game(Player player, Connection serverInfos)
        {
            Player = player;

            string endPoint = serverInfos.ConnectionInfo.RemoteEndPoint.ToString();
            serverIp = endPoint.Split(':').First();
            serverPort = UInt16.Parse(endPoint.Split(':').Last());

            NetworkComms.SendObject<Component<string>>("Ready", serverIp, serverPort,
                new Component<string>(player.RoomHash, player.Id.ToString()));
        }

        public void receivedBet(Bet bet)
        {
            if (bet.PlayerId == 0)
            {
                Console.WriteLine("There is no current bet");
            }
            else
            {
                Console.WriteLine("Current bet is: " + SignsName[bet.AtoutSign]
                    + " of " + bet.BetValue
                    + " from player " + bet.PlayerId);
            }
            Bet = bet;
            if (bet.CurrentPlayerId == Player.Id)
            {
                string newBet = askBet();
                bool isDone = treatBet(newBet);
                if (isDone == false)
                {
                    sendBet();
                }
            }
        }

        private bool isAGoodSign(string bet)
        {
            int value;

            if (!int.TryParse(bet.Split('/').First(), out value) || value < 0 || value >= 4)
            {
                Console.WriteLine("Wrong sign");
                return (false);
            }
            return (true);
        }

        private bool isAGoodValue(string bet)
        {
            UInt16 value;

            if (!UInt16.TryParse(bet.Split('/').Last(), out value) || value < 80 || value > 160)
            {
                Console.WriteLine("Wrong value");
                return (false);
            }
            return (true);
        }

        private bool canCoinche()
        {
            return (Bet.BetValue != 0 && Bet.PlayerId != Player.Id && Bet.PlayerId != (Player.Id + 2) % 4 && !Bet.Coinche); //Le bet n'est fait ni par nous ni par un allie
        }

        private bool specialCommand(string bet)
        {
            if (bet == "pass" || (bet == "coinche" && canCoinche() == true) || (bet == "surcoinche" && Bet.Coinche))
            {
                return (true);
            }
            return (false);
        }

        public string askBet()
        {
            Console.WriteLine("It's your turn for the bet");
            string bet;
            do
            {
                Console.WriteLine("\nBet format: Signs/Value");
                Console.WriteLine("Signs: (0: {0}, 1: {1}, 2: {2}, 3: {3})", SignsName[0], SignsName[1], SignsName[2], SignsName[3]);
                Console.WriteLine("Value has to be between 80 and 160");
                Console.WriteLine("Other commands: \npass\ncoinche\nsurcoinche");
                bet = Console.ReadLine();
            } while (specialCommand(bet) == false && (isAGoodSign(bet) == false || isAGoodValue(bet) == false));
            return (bet);
        }

        private bool treatBet(string bet)
        {
            bool isDone = true;

            if ((Bet.Coinche = (bet == "coinche")))
            {
                //sendCoinche();
            }
            else if ((Bet.Coinche = (bet == "pass")))
            {
                //sendPass();
            }
            else if ((Bet.Coinche = (bet == "surcoinche")))
            {
                //sendSurcoinche();
            }
            else
            {
                isDone = false;
            }

            return (isDone);
        }

        private void sendBet()
        {
            Console.WriteLine("\nSending bet");
            NetworkComms.SendObject<Component<Bet>>("Bet", serverIp, serverPort, new Component<Bet>(Player.RoomHash, Bet));
        }
    }
}
