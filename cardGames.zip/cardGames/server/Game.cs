﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NetworkCommsDotNet;
using NetworkCommsDotNet.Connections;
using Common;

namespace server
{
    public class Game
    {
        public string RoomHash { get; private set; }
        private List<Player> Players = new List<Player>();
        private Bet Bet;
        private int NbPlayerReady;
        private UInt16 passBet = 0;

        public Game(List<NetworkUser> users)
        {
            NbPlayerReady = 0;
            init(users);
        }

        public void playerReady(string message)
        {
            Console.WriteLine("Player " + message + " ready");
            NbPlayerReady++;
            if (NbPlayerReady == 1)
            {
                Console.WriteLine("All players are ready\nGame starting");
                sendBet();
            }
        }

        void sendUserDatas()
        {
            foreach (Player player in Players)
            {
                player.NetUser.ConnectionInfos.SendObject<Player>("Start", player);
            }
        }

        private void sendBet()
        {
            Console.WriteLine("Sending bet to players");
            foreach (Player player in Players)
            {
                player.NetUser.ConnectionInfos.SendObject<Component<Bet>>("Bet", new Component<Bet>(RoomHash, Bet));
            }
        }

        public void receivePassBet(string bet)
        {
            Console.WriteLine("Player " + Bet.CurrentPlayerId + " has passed without betting");
            passBet += 1;
            receiveBet(bet, false);
        }

        public void receiveBet(string bet, bool valueBet = true)
        {
            if (valueBet == true)
            {
                passBet = 0;
                Bet.AtoutSign = UInt16.Parse(bet.Split('/').First());
                Bet.BetValue = UInt16.Parse(bet.Split('/').Last());
                Bet.PlayerId = Bet.CurrentPlayerId;
            }
            if (passBet == 3)
            {
                passBet = 0;
                if (Bet.BetValue != 0)
                {
                    Console.WriteLine("Bet phase is done");
                    //start game
                    return ;
                }
            }
            Bet.CurrentPlayerId = (UInt16)(((int)Bet.CurrentPlayerId + 1) % 5);
            Bet.CurrentPlayerId = Bet.CurrentPlayerId == 0 ? (UInt16)1 : Bet.CurrentPlayerId;
            sendBet();
        }

        private void initBet()
        {
            Bet = new Bet(Players[0].Id);
        }

        public void start()
        {
            initBet();
            sendUserDatas();
        }

        private void init(List<NetworkUser> users)
        {
            List<Card> deck = createShuffledDeck();
            string roomHash = $"{users[0].Hash}:{users[1].Hash}:{users[2].Hash}:{users[3].Hash}";
            RoomHash = roomHash;
            for (int i = 0; i < 4; ++i)
            {
                int id = i + 1;
                int groupId = i % 2;
                List<Card> userDeck = new List<Card>();
                for (int j = 0; j < 8; ++j)
                {
                    userDeck.Add(deck[0]);
                    deck.RemoveAt(0);
                }
                Player player = new Player((UInt16)id, (UInt16)groupId, roomHash, userDeck);
                player.setNetworkUser(users[i]);
                Players.Add(player);
            }
        }

        private static List<Card> createShuffledDeck()
        {
            List<Card> deck = new List<Card>();

            for (UInt16 i = 0; i < 4; ++i)
            {
                for (UInt16 j = 7; j <= 14; ++j)
                {
                    deck.Add(new Card(i, j));
                }
            }
            Random rng = new Random();
            int n = deck.Count;
            while (n > 1)
            {
                n--;
                int k = rng.Next(n + 1);
                Card value = deck[k];
                deck[k] = deck[n];
                deck[n] = value;
            }

            return deck;
        }

        public void disconnectAll()
        {
            foreach (Player player in Players)
            {
                player.NetUser.ConnectionInfos.SendObject<string>("500", " a player has been disconnected from the room");
            }
            
            for (int i = 0; i < 4; i++)
            {
                disconnectPlayer(Players[0].NetUser.ConnectionInfos);
            }
        }

        public void disconnectPlayer(Connection connection)
        {
            int i = 0;
            foreach (Player player in Players)
            {
                if (player.NetUser.Hash == connection.ConnectionInfo.NetworkIdentifier)
                {
                    Console.WriteLine("Player removed from lists");
                    Players.RemoveAt(i);
                    return;
                }
                ++i;
            }
        }
    }
}
