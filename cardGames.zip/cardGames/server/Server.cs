﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common;
using NetworkCommsDotNet;
using NetworkCommsDotNet.Connections;

namespace server
{
    class Server
    {
        private UInt16 MaxClient;
        private List<NetworkUser> NetworkUsers = new List<NetworkUser>();
        private Dictionary<string, Game> Games = new Dictionary<string, Game>();

        public Server(UInt16 port, UInt16 maxClient = 40)
        {
            MaxClient = maxClient;
            NetworkComms.AppendGlobalConnectionEstablishHandler(connectionHandler);
            NetworkComms.AppendGlobalConnectionCloseHandler(disconnectionHandler);//to implem
            NetworkComms.AppendGlobalIncomingUnmanagedPacketHandler(unknownHandler);

            NetworkComms.AppendGlobalIncomingPacketHandler<Component<Bet>>("Bet", receiveBet);
            NetworkComms.AppendGlobalIncomingPacketHandler<Component<string>>("Ready", setPlayerReady);

            Connection.StartListening(ConnectionType.TCP, new System.Net.IPEndPoint(System.Net.IPAddress.Any, port));

            foreach (System.Net.IPEndPoint localEndPoint in Connection.ExistingLocalListenEndPoints(ConnectionType.TCP))
            {
                Console.WriteLine("{0}:{1}", localEndPoint.Address, localEndPoint.Port);
            }
        }

        private void setPlayerReady(PacketHeader packetHeader, Connection connection, Component<string> comp)
        {
            Games[comp.RoomHash].playerReady(comp.Object);
        }

        public void start()
        {
            while (true)
            {
                Console.ReadKey(true);
            }
        }

        private void connectionHandler(Connection connection)
        {
            Console.WriteLine("New connection {0}", NetworkComms.TotalNumConnections());
            if (NetworkComms.TotalNumConnections() > MaxClient)
            {
                Console.WriteLine("Warning: Connection refused due to server full");
                connection.SendObject("500");
                connection.CloseConnection(false);
            }
            else
            {
                NetworkUsers.Add(getNetworkUser(connection));
                connection.SendObject("200");

                if (NetworkUsers.Count % 1 == 0)//4 debug
                {
                    List<NetworkUser> localUsers = new List<NetworkUser>();

                    for (int i = 0; i < 1; i++)//i < 4 debug
                    {
                        localUsers.Add(NetworkUsers[0]);
                        NetworkUsers.RemoveAt(0);
                    }
                    var game = new Game(localUsers);
                    Console.WriteLine("New game started: " + game.RoomHash);//debug
                    Games[game.RoomHash] = game;
                    game.start();
                }
            }
        }

        private void unknownHandler(PacketHeader packetHeader, Connection connection, byte[] message)
        {
            Console.WriteLine("Unknown packet received: " + message);
        }

        private void disconnectionHandler(Connection connection)
        {
            foreach (KeyValuePair<string, Game> game in Games)
            {
                if (game.Key.Contains(connection.GetHashCode().ToString()) == true)
                {
                    Console.WriteLine("A Player has disconnected from room " + Games[game.Key].RoomHash);
                    Games[game.Key].disconnectAll();
                    return;
                }
            }
            Console.WriteLine("A client has disconnected from the server");
        }

        private static NetworkUser getNetworkUser(Connection connection)
        { 
            var endPoint = connection.ConnectionInfo.RemoteEndPoint.ToString();
            string ip = endPoint.Substring(0, endPoint.LastIndexOf(":"));
            UInt16 port = UInt16.Parse(endPoint.Split(':').Last());
            string hash = connection.ConnectionInfo.NetworkIdentifier;

            return new NetworkUser(connection, ip, port, hash);
        }

        private void receiveBet(PacketHeader header, Connection connection, Component<Bet> comp)
        {
            Games[comp.RoomHash].receiveBet(comp.Object);
        }
    }
}
