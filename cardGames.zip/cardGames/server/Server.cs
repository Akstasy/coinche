﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common;
using NetworkCommsDotNet;
using NetworkCommsDotNet.Connections;

namespace server
{
    class Server
    {
        private UInt16 MaxClient;
        private List<NetworkUser> NetworkUsers = new List<NetworkUser>();
        private Dictionary<string, Game> Games = new Dictionary<string, Game>();

        /// <summary>
        /// Server constructor with callbacks initialisation, connection activation and port + ip listing
        /// </summary>
        public Server(UInt16 port, UInt16 maxClient = 40)
        {
            MaxClient = maxClient;
            NetworkComms.AppendGlobalConnectionEstablishHandler(connectionHandler);
            NetworkComms.AppendGlobalConnectionCloseHandler(disconnectionHandler);//to implem
            NetworkComms.AppendGlobalIncomingUnmanagedPacketHandler(unknownHandler);

            NetworkComms.AppendGlobalIncomingPacketHandler<Component<string>>("Bet", receiveBet);
            NetworkComms.AppendGlobalIncomingPacketHandler<Component<string>>("PassBet", receivePassBet);
            NetworkComms.AppendGlobalIncomingPacketHandler<Component<string>>("Ready", setPlayerReady);

            Connection.StartListening(ConnectionType.TCP, new System.Net.IPEndPoint(System.Net.IPAddress.Any, port));

            foreach (System.Net.IPEndPoint localEndPoint in Connection.ExistingLocalListenEndPoints(ConnectionType.TCP))
            {
                Console.WriteLine("{0}:{1}", localEndPoint.Address, localEndPoint.Port);
            }
        }

        /// <summary>
        /// Function called when a player pass his turn
        /// <param PacketHeader="packetHeader">no description needed</param>
        /// <param Connection="connection">object containing user infos</param>
        /// <param Component<string>="comp">Component is an object that possess a header with room name and the sent object</param>
        /// </summary>
        private void receivePassBet(PacketHeader packetHeader, Connection connection, Component<string> comp)
        {
            Games[comp.RoomHash].receivePassBet(comp.Object);
        }

        /// <summary>
        /// Function called when a player game is started and ready
        /// <param PacketHeader="packetHeader">no description needed</param>
        /// <param Connection="connection">object containing user infos</param>
        /// <param Component<string>="comp">Component is an object that possess a header with room name and the sent object</param>
        /// </summary>
        private void setPlayerReady(PacketHeader packetHeader, Connection connection, Component<string> comp)
        {
            Games[comp.RoomHash].playerReady(comp.Object);
        }

        /// <summary>
        /// Basic function for server to stay actif
        /// </summary>
        public void start()
        {
            while (true)
            {
                Console.ReadKey(true);
            }
        }

        /// <summary>
        /// Function called when a player join the server
        /// <param Connection="connection">object containing user infos</param>
        /// </summary>
        private void connectionHandler(Connection connection)
        {
            Console.WriteLine("New connection {0}", NetworkComms.TotalNumConnections());
            if (NetworkComms.TotalNumConnections() > MaxClient)
            {
                Console.WriteLine("Warning: Connection refused due to server full");
                connection.SendObject("500");
                connection.CloseConnection(false);
            }
            else
            {
                NetworkUsers.Add(getNetworkUser(connection));
                connection.SendObject("200");

                if (NetworkUsers.Count % 4 == 0)
                {
                    List<NetworkUser> localUsers = new List<NetworkUser>();

                    for (int i = 0; i < 4; i++)
                    {
                        localUsers.Add(NetworkUsers[0]);
                        NetworkUsers.RemoveAt(0);
                    }
                    var game = new Game(localUsers);
                    Console.WriteLine("New game started in room " + game.RoomHash);
                    Games[game.RoomHash] = game;
                    game.start();
                }
            }
        }

        /// <summary>
        /// Function called when an unknown packet is received
        /// </summary>
        private void unknownHandler(PacketHeader packetHeader, Connection connection, byte[] message)
        {
            Console.WriteLine("Unknown packet received: " + message);
        }

        /// <summary>
        /// Function called when a player leave the server
        /// <param Connection="connection">object containing user infos</param>
        /// </summary>
        private void disconnectionHandler(Connection connection)
        {
            foreach (KeyValuePair<string, Game> game in Games)
            {
                if (game.Key.Contains(connection.ConnectionInfo.NetworkIdentifier) == true)
                {
                    Console.WriteLine("A Player has disconnected from room " + Games[game.Key].RoomHash);
                    Games[game.Key].disconnectPlayer(connection);
                    Games[game.Key].disconnectAll();
                    return;
                }
            }
            removeNetUser(connection);
            Console.WriteLine("A client has disconnected from the server");
        }

        private void removeNetUser(Connection connection)
        {
            int i = 0;
            foreach (NetworkUser user in NetworkUsers)
            {
                if (user.Hash == connection.ConnectionInfo.NetworkIdentifier)
                {
                    Console.WriteLine("user removed from waiting list");
                    NetworkUsers.RemoveAt(i);
                    return;
                }
                ++i;
            }
        }

        /// <summary>
        /// Function called when an user join the server to create a new user
        /// <param Connection="connection">object containing user infos</param>
        /// </summary>
        private static NetworkUser getNetworkUser(Connection connection)
        { 
            var endPoint = connection.ConnectionInfo.RemoteEndPoint.ToString();
            string ip = endPoint.Substring(0, endPoint.LastIndexOf(":"));
            UInt16 port = UInt16.Parse(endPoint.Split(':').Last());
            string hash = connection.ConnectionInfo.NetworkIdentifier;

            return new NetworkUser(connection, ip, port, hash);
        }

        /// <summary>
        /// Function called when a player send a bet
        /// <param PacketHeader="packetHeader">no description needed</param>
        /// <param Connection="connection">object containing user infos</param>
        /// <param Component<string>="comp">Component is an object that possess a header with room name and the sent object</param>
        /// </summary>
        private void receiveBet(PacketHeader header, Connection connection, Component<string> comp)
        {
            Games[comp.RoomHash].receiveBet(comp.Object);
        }
    }
}
