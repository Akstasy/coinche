﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common;
using NetworkCommsDotNet;
using NetworkCommsDotNet.Connections;
using NetworkCommsDotNet.Connections.TCP;

namespace client
{
    public class Game
    {
        const int BET_PHASE_DONE = 5;

        //END fail contract: addition of both scores
        public Bet Bet { get; private set; }
        private static readonly string[] SignsName = { "Clubs", "Spades", "Hearts", "Diamonds" }; //♣♠♥♦
        private static readonly string[] CardsName = { "7", "8", "9", "10", "Jack", "Queen", "King", "Ace"};
        private Player MyPlayer;
        private Table MyTable = new Table(0);
        private Connection ServerInfos;
        private string ServerIp;
        private UInt16 ServerPort;

        private bool ItIsMyTurn;
        private bool ImWaiting = false;

        private object canDisplay = new object();

        public Game(Player player, Connection serverDatas)
        {
            MyPlayer = player;

            string endPoint = serverDatas.ConnectionInfo.RemoteEndPoint.ToString();
            ServerIp = endPoint.Split(':').First();
            ServerPort = UInt16.Parse(endPoint.Split(':').Last());

            ServerInfos = TCPConnection.GetConnection(new ConnectionInfo(ServerIp, ServerPort));

            ServerInfos.SendObject<Component<string>>("Ready", new Component<string>(player.RoomHash, player.Id.ToString()));
        }

        public void ReceiveScores(string scores)
        {
            int[] Scores = new int[3];
            int my_score = MyPlayer.Id % 2;
            Scores[0] = int.Parse(scores.Split(' ')[0]);
            Scores[1] = int.Parse(scores.Split(' ')[1]);
            Scores[2] = int.Parse(scores.Split(' ')[2]);
            Console.WriteLine("Current scores are:\nTeam 1: " + Scores[0] + "\nTeam 2: " + Scores[1]);
            if (Scores[2] == MyPlayer.Id % 2)
            {
                Console.WriteLine("You won this round!");
            }
            MyTable.SetTeamScores(0, Scores[0]);
            MyTable.SetTeamScores(1, Scores[1]);
        }

        public void ReceiveBet(Bet bet)
        {
            if (bet.PlayerId == 0)
            {
                Console.WriteLine("\nThere is no current bet");
            }
            else
            {
                Console.WriteLine("Current bet: Trump is " + SignsName[bet.AtoutSign]
                    + " and value is " + bet.BetValue
                    + " from player " + bet.PlayerId);
            }
            Bet = bet;
            if (bet.CurrentPlayerId == BET_PHASE_DONE)
            {}
            else if (bet.CurrentPlayerId != MyPlayer.Id)
            {
                Console.WriteLine("It's player " + bet.CurrentPlayerId + "'s turn to bet");
                if ((CanCoinche() || CanSurcoinche()) && ImWaiting == false)
                {
                    ImWaiting = true;
                    GetUserSpecialCommands();
                }
            }
            else if (bet.CurrentPlayerId == MyPlayer.Id)
            {
                lock (synlock)
                {
                    ItIsMyTurn = true;
                }
                string newBet = AskBet();
                bool isDone = TreatBet(newBet);
                if (isDone == false)
                {
                    SendBet(newBet);
                }
                lock (synlock)
                {
                    ItIsMyTurn = false;
                }
            }
        }

        private bool IsAGoodSign(string bet)
        {
            int value;

            if (!int.TryParse(bet.Split('/').First(), out value) || value < 0 || value >= 4)
            {
                Console.WriteLine("Wrong sign");
                return (false);
            }
            return (true);
        }

        private bool IsAGoodValue(string bet)
        {
            UInt16 value;

            if (!UInt16.TryParse(bet.Split('/').Last(), out value) || value < 80 || value > 160)
            {
                Console.WriteLine("Wrong value");
                return (false);
            }
            return (true);
        }

        private bool CanCoinche()
        {
            return (Bet.BetValue != 0 && Bet.PlayerId != MyPlayer.Id && Bet.PlayerId != (MyPlayer.Id + 2) % 4 && !Bet.Coinche);
        }

        private bool CanSurcoinche()
        {
            return (!IsAllyInBet(Bet.PlayerId) && Bet.Coinche && Bet.BetValue != 0);
        }

        private bool IsAllyInGame(int PlayerId)
        {
            return (PlayerId % 2 == MyTable.CurrentPlayerId % 2);
        }

        private bool IsAllyInBet(int PlayerId)
        {
            return (PlayerId % 2 == Bet.CurrentPlayerId % 2);
        }

        private bool SpecialCommand(string bet)
        {
            if (bet == "pass" || (bet == "coinche" && CanCoinche() == true) || (bet == "surcoinche" && Bet.Coinche))
            {
                return (true);
            }
            return (false);
        }

        private object synlock = new object();

        private void GetUserSpecialCommands()
        {
            string buffer = "";
            
            while (true)
            {
                lock (synlock)
                {
                    if (ItIsMyTurn)
                    {
                        break;
                    }
                }
                if (Console.KeyAvailable)
                {
                    Console.WriteLine("KeyAvailable");
                    ConsoleKeyInfo key = Console.ReadKey(true);
                    buffer += key.Key.ToString();
                    if (key.Key == ConsoleKey.Enter)
                    {
                        Console.WriteLine("enter");
                        buffer = "";
                        if (SpecialCommand(buffer) == true)
                        {
                            ServerInfos.SendObject<Component<string>>(buffer.First().ToString().ToUpper() + buffer.Substring(1)
                                , new Component<string>(MyPlayer.RoomHash, buffer));
                            return;
                        }
                        Console.WriteLine("Other commands: pass " + (CanCoinche() ? "/ coinche " : (CanSurcoinche() ? "/ surcoinche" : "")));
                    }
                }
            }
            ImWaiting = false;
        }

        public string AskBet()
        {
            DisplayCards();
            Console.WriteLine("\nIt's your turn for the bet");
            string bet;
            do
            {
                Console.WriteLine("\nBet format: Sign/Value");
                Console.WriteLine("Signs: (0: {0}, 1: {1}, 2: {2}, 3: {3})", SignsName[0], SignsName[1], SignsName[2], SignsName[3]);
                Console.WriteLine("Value has to be between 80 and 160");
                Console.WriteLine("Other commands: pass " + (CanCoinche() ? "/ coinche " : (CanSurcoinche() ? "/ surcoinche" : "")));
                bet = Console.ReadLine();
            } while (SpecialCommand(bet) == false && (IsAGoodSign(bet) == false || IsAGoodValue(bet) == false));
            return (bet);
        }

        private void SendPass()
        {
            ServerInfos.SendObject<Component<string>>("PassBet", new Component<string>(MyPlayer.RoomHash, ""));
        }

        private void SendCoinche()
        {
            ServerInfos.SendObject<Component<string>>("Coinche", new Component<string>(MyPlayer.RoomHash, ""));
        }

        private void SendSurcoinche()
        {
            ServerInfos.SendObject<Component<string>>("Surcoinche", new Component<string>(MyPlayer.RoomHash, ""));
        }

        private bool TreatBet(string bet)
        {
            bool isDone = true;

            if ((Bet.Coinche = (bet == "coinche")))
            {
                SendCoinche();
            }
            else if ((Bet.Coinche = (bet == "pass")))
            {
                SendPass();
            }
            else if ((Bet.Coinche = (bet == "surcoinche")))
            {
                SendSurcoinche();
            }
            else
            {
                isDone = false;
            }

            return (isDone);
        }

        private void SendBet(string bet)
        {
            Console.WriteLine("\nSending bet");
            ServerInfos.SendObject<Component<string>>("Bet", new Component<string>(MyPlayer.RoomHash, bet));
        }

        public void ReceiveTable(Table table)
        {
            MyTable = table;
            DisplayTable();
            AskCard();
        }

        private void AskCard()
        {
            string command = "";
            lock (canDisplay)
            {
                if (MyTable.CurrentPlayerId == MyPlayer.Id)
                {
                    Console.WriteLine("It's your turn to play");
                    Console.WriteLine("Please choose your card");
                    do
                    {
                        Console.WriteLine("Format: Sign/Value");
                        Console.WriteLine("Signs: (0: {0}, 1: {1}, 2: {2}, 3: {3})", SignsName[0], SignsName[1], SignsName[2], SignsName[3]);
                        Console.Write("Values: (11: {0}, 12: {1}, 13: {2}, 14: {3})", CardsName[4], CardsName[5], CardsName[6], CardsName[7]);
                        Console.WriteLine();
                        command = Console.ReadLine();
                    } while (IsAGameCommand(command) == false);
                    ServerInfos.SendObject<Component<Table>>("Table", new Component<Table>(MyPlayer.RoomHash, MyTable));
                }
                else
                {
                    Console.WriteLine("It's player " + MyTable.CurrentPlayerId + "'s turn");
                }
            }
        }

        private bool IsAGameCommand(string command)
        {
            int cardSign;
            int cardValue;

            try
            {
                cardSign = int.Parse(command.Split('/').First());
                cardValue = int.Parse(command.Split('/').Last());
            }
            catch (Exception e)
            {
                Console.WriteLine("Error: " + e.Message);
                return (false);
            }
            return (PutCardOnTable(cardSign, cardValue));
        }

        private bool PutCardOnTable(int cardSign, int cardValue)
        {
            int index, i = 0;

            foreach (Card card in MyPlayer.Cards)
            {
                if (card.Sign == cardSign && card.Value == cardValue && card.Playable == true)
                {
                    index = GetTableLastEmptyIndex();
                    MyTable.CurrentCards[index].SetCard(card.Sign, card.Value, card.Playable, MyPlayer.Id);
                    MyPlayer.Cards.RemoveAt(i);
                    return (true);
                }
                i++;
            }
            return (false);
        }

        private int GetTableLastEmptyIndex()
        {
            int id = 0;

            foreach (PlayerCard PlayerCard in MyTable.CurrentCards)
            {
                if (PlayerCard.card.Value == 0)
                {
                    break ;
                }
                id++;
            }
            return (id);
        }

        private int FindPlayerCardId(PlayerCard myCard)
        {
            int id = 0;

            foreach (Card card in MyPlayer.Cards)
            {
                if (card.Value == myCard.card.Value
                    && card.Sign == myCard.card.Sign)
                {
                    return (id);
                }
                id++;
            }

            return (id);
        }

        private void DisplayTable()
        {
            lock (canDisplay)
            {
                bool init = false;
                foreach (PlayerCard TablePlayerCard in MyTable.CurrentCards)
                {
                    if (TablePlayerCard.PlayerId == -1)
                    {
                        continue;
                    }
                    if (init == false)
                    {
                        init = true;
                        Console.WriteLine("\nCurrent Table is :");
                    }
                    Console.WriteLine(CardsName[TablePlayerCard.card.Value - 7] + " / " + SignsName[TablePlayerCard.card.Sign] + " from player " + TablePlayerCard.PlayerId);
                }
                if (init == false)
                {
                    Console.WriteLine("\nThe Table is Currently empty");
                }
                Console.WriteLine();
            }
        }

        public void ReceiveCards(Player player)
        {
            MyPlayer.Cards = player.Cards;
            DisplayCards(true);
        }
        public void ReceiveEnd(string message)
        {
            Console.WriteLine("End of the game");
            if (MyTable.GetTeamScores(MyPlayer.Id % 2) > MyTable.GetTeamScores((MyPlayer.Id + 1) % 2))
            {
                Console.WriteLine("You are the winner of this game! Bravo!");
                if (Bet.PlayerId % 2 == MyPlayer.Id % 2
                    && Bet.BetValue <= MyTable.GetTeamScores(MyPlayer.Id % 2))
                {
                    Console.WriteLine("Congratulation you won your bet");
                    if (Bet.Multiplier != 1)
                    {
                        Console.WriteLine("The actual multiplier is " + Bet.Multiplier);
                    }
                    Console.WriteLine("Your final score is "
                        + (Bet.BetValue * Bet.Multiplier + MyTable.GetTeamScores(MyPlayer.Id % 2)));
                }
            }
        }

        private void DisplayCards(bool displayNotPlayable = false)
        {
            lock (canDisplay)
            {
                Console.WriteLine("\nPlayer cards:");
                foreach (Card card in MyPlayer.Cards)
                {
                    if (card.Value != 0)
                    {
                        Console.WriteLine(SignsName[card.Sign] + " / " + CardsName[card.Value - 7]
                            + (displayNotPlayable == true && card.Playable == false ? " / Not playable" : ""));
                    }
                }
            }
        }

        public void ReceiveCoinche(Bet bet)
        {
            string command;

            Console.WriteLine("\nYou received a Coinche from an opponent\nCurrent bet multiplier is now 2");
            do
            {
                command = "";
                Console.WriteLine("Available commands: surcoinche / pass");
                Console.WriteLine("If you choose to surcoinche, the bet value multiplier will be 4");
            } while ((SurcoincheAnswer(out command)) == false);
            ServerInfos.SendObject<Component<string>>("Surcoinche", new Component<string>(MyPlayer.RoomHash, command));
        }

        private bool SurcoincheAnswer(out string command)
        {
            command = Console.ReadLine();
            return (command == "pass" || command == "surcoinche");
        }
    }
}
