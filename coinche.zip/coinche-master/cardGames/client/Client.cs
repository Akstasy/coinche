﻿using System;
using System.Linq;
using System.Threading;
using Common;
using NetworkCommsDotNet;
using NetworkCommsDotNet.Connections;
using NetworkCommsDotNet.Connections.TCP;

namespace client
{
    class Client
    {
        public Player Player { get; set; }
        private NetworkUser NetUser;
        private Game Game;

        public Client()
        {
            InitCallbacks();
            ConnectionToServer();
        }

        void ConnectionToServer()
        {
            Console.WriteLine("Please enter your coinche favorite IP and Port in the format 100.100.100.100:100 and press enter:");
            string serverInfo = Console.ReadLine();
            string serverIp = serverInfo.Substring(0, serverInfo.LastIndexOf(":"));
            UInt16 serverPort = UInt16.Parse(serverInfo.Split(':').Last());

            NetUser = new NetworkUser(null, serverIp, serverPort);

            ConnectionInfo connInfo = new ConnectionInfo(serverIp, serverPort);
            NetUser.ConnectionInfos = TCPConnection.GetConnection(connInfo);

            NetworkComms.SendObject("Connection", serverIp, serverPort, "Asking for connection");
        }

        void InitCallbacks()
        {
            NetworkComms.AppendGlobalIncomingPacketHandler<string>("200", ConfirmationHandler);
            NetworkComms.AppendGlobalIncomingPacketHandler<string>("500", ErrorHandler);
            NetworkComms.AppendGlobalIncomingPacketHandler<Player>("Start", StartGame);
            NetworkComms.AppendGlobalIncomingUnmanagedPacketHandler(UnknownHandler);
            NetworkComms.AppendGlobalIncomingPacketHandler<Component<Bet>>("Bet", ReceiveBet);
            NetworkComms.AppendGlobalIncomingPacketHandler<Component<Table>>("Game", ReceiveTable);
            NetworkComms.AppendGlobalIncomingPacketHandler<Component<Player>>("Cards", ReceiveCards);
            NetworkComms.AppendGlobalIncomingPacketHandler<Component<Bet>>("Coinche", ReceiveCoinche);
            NetworkComms.AppendGlobalIncomingPacketHandler<Component<string>>("Message", ReceiveMessage);
            NetworkComms.AppendGlobalIncomingPacketHandler<Component<string>>("Scores", ReceiveScores);
            NetworkComms.AppendGlobalIncomingPacketHandler<Component<string>>("End", ReceiveEnd);
        }

        private void ReceiveEnd(PacketHeader header, Connection connection, Component<string> comp)
        {
            Game.ReceiveEnd(comp.Object);
        }
        private void ReceiveScores(PacketHeader header, Connection connection, Component<string> comp)
        {
            Game.ReceiveScores(comp.Object);
        }

        private void ReceiveMessage(PacketHeader header, Connection connection, Component<string> comp)
        {
            Console.WriteLine(comp.Object);
        }

        private void ReceiveCoinche(PacketHeader header, Connection connection, Component<Bet> comp)
        {
            Game.ReceiveCoinche(comp.Object);
        }

        private void ReceiveCards(PacketHeader header, Connection connection, Component<Player> comp)
        {
            Game.ReceiveCards(comp.Object);
        }

        private void ReceiveTable(PacketHeader header, Connection connection, Component<Table> comp)
        {
            Game.ReceiveTable(comp.Object);
        }

        private void ReceiveBet(PacketHeader header, Connection connection, Component<Bet> comp)
        {
            Game.ReceiveBet(comp.Object);
        }

        private static void ConfirmationHandler(PacketHeader header, Connection connection, string message)
        {
            Console.WriteLine("Connection OK");
        }

        private static void ErrorHandler(PacketHeader header, Connection connection, string message)
        {
            Console.WriteLine("Connection KO " + message);
            NetworkComms.Shutdown();
            System.Environment.Exit(84);
        }

        private void UnknownHandler(PacketHeader packetHeader, Connection connection, byte[] message)
        {
            Console.WriteLine("Unknown packet received: " + message);
        }

        public void StartGame(PacketHeader header, Connection connection, Player player)
        {
            Console.WriteLine("Start received");
            Player = player;
            Player.SetNetworkUser(NetUser);
            Player.NetUser.Hash = NetUser.ConnectionInfos.ConnectionInfo.NetworkIdentifier;
            Game = new Game(Player, connection);
        }

        public void Run()
        {
            while (true)
            {
                Thread.Sleep(5000);
            }
        }
    }
}