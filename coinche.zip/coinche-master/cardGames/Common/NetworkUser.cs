﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NetworkCommsDotNet.Connections;

namespace Common
{
    public class NetworkUser
    {
        public string Ip { get; private set; }
        public UInt16 Port { get; private set; }
        public string Hash;
        public Connection ConnectionInfos;

        public NetworkUser(Connection connection, string ip, UInt16 port, string hash = "")
        {
            ConnectionInfos = connection;
            Ip = ip;
            Port = port;
            Hash = hash;
        }
    }
}
