﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common;
using ProtoBuf;

namespace Common
{
    [ProtoContract]
    public class PlayerCard
    {
        [ProtoMember(1)]
        public Card card;
        [ProtoMember(2)]
        public int PlayerId;

        protected PlayerCard() { }

        public PlayerCard(UInt16 sign, UInt16 value, bool playable, int id)
        {
            card = new Card(sign, value, playable);
            PlayerId = id;
        }

        public void SetCard(UInt16 sign, UInt16 value, bool playable, int id)
        {
            card.SetSign(sign);
            card.SetValue(value);
            card.Playable = playable;
            PlayerId = id;
        }
    }
}
