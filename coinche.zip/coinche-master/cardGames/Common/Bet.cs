﻿using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common;

namespace Common
{
    [ProtoContract]
    public class Bet
    {
        [ProtoMember(1)]
        public bool Coinche;

        [ProtoMember(2)]
        public UInt16 BetValue;

        [ProtoMember(3)]
        public UInt16 AtoutSign;

        [ProtoMember(4)]
        public UInt16 PlayerId;

        [ProtoMember(5)]
        public UInt16 CurrentPlayerId;

        [ProtoMember(6)]
        public UInt16 Multiplier;

        /// <summary>
        /// Parameterless constructor required for protobuf
        /// </summary>
        protected Bet() { }

        public Bet(UInt16 currentPlayerId) {
            Multiplier = 1;
            Coinche = false;
            BetValue = 0;
            AtoutSign = 0;
            PlayerId = 0;
            CurrentPlayerId = currentPlayerId;
        }
    }
}
