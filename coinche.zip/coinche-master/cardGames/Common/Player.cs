﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProtoBuf;

namespace Common
{
    [ProtoContract]
    public class Player
    {
        public bool IsReady = false;
        public NetworkUser NetUser;
        [ProtoMember(1)]
        public UInt16 Id;
        [ProtoMember(2)]
        public UInt16 Group;

        public List<Card> Cards = new List<Card>();

        [ProtoMember(3)]
        public string RoomHash;

        // sign, value
        [ProtoMember(4)]
        private UInt16[] _cards = new UInt16[24];

        [ProtoBeforeSerialization]
        private void Serialize()
        {
            UInt16 i = 0;

            foreach (var card in Cards)
            {
                _cards[i] = card.Sign;
                _cards[i + 1] = card.Value;
                _cards[i + 2] = (UInt16)(card.Playable == true ? 1 : 0);
                i += 3;
            }
        }

        [ProtoAfterDeserialization]
        private void Deserialize()
        {
            foreach (Card card in Cards)
            {
                Console.WriteLine("before mycards" + card.Value);
            }
            Cards.Clear();
            foreach (Card card in Cards)
            {
                Console.WriteLine("mycards"+card.Value);
            }
            for (var i = 0; i < _cards.Length; i += 3)
            {
                Cards.Add(new Card(_cards[i], _cards[i + 1], _cards[i + 2] == 1 ? true : false));
            }
        }

        public void SetNetworkUser(NetworkUser netUser)
        {
            NetUser = netUser;
        }

        protected Player() { }

        public Player(UInt16 id, UInt16 groupId, string roomHash, List<Card> cards)
        {
            Id = id;
            Group = groupId;
            RoomHash = roomHash;
            Cards = cards;
        }
    }
}
