﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProtoBuf;

namespace Common
{
    [ProtoContract]
    public class Table
    {
        public PlayerCard[] CurrentCards = new PlayerCard[4];
        [ProtoMember(2)]
        private int[] TeamScores = new int[2];
        [ProtoMember(3)]
        public int CurrentPlayerId;

        // sign, value
        [ProtoMember(4)]
        private UInt16[] _cards;
        // ID
        [ProtoMember(5)]
        private int[] _cardsId;

        [ProtoBeforeSerialization]
        private void Serialize()
        {
            UInt16 i = 0;

            _cardsId = new int[4];
            _cards = new UInt16[12];
            foreach (var card in CurrentCards)
            {
                _cards[i] = card.card.Sign;
                _cards[i + 1] = card.card.Value;
                _cards[i + 2] = (UInt16)(card.card.Playable == true ? 1 : 0);
                _cardsId[i / 3] = (card.PlayerId);
                i += 3;
            }
        }

        [ProtoAfterDeserialization]
        private void Deserialize()
        {
            for (var i = 0; i < _cards.Count(); i += 3)
            {
                if (i < 12)
                {
                    CurrentCards[i / 3] = (new PlayerCard(_cards[i], _cards[i + 1], _cards[i + 2] == 1 ? true : false, _cardsId[i / 3]));
                }
            }
        }

        /// <summary>
        /// Parameterless constructor required for protobuf
        /// </summary>
        protected Table() { }

        public Table(int currentPlayerId)
        {
            CurrentPlayerId = currentPlayerId;
            TeamScores[0] = 0;
            TeamScores[1] = 0;
            for (int i = 0; i < 4; i++)
            {
                CurrentCards[i] = new PlayerCard(0, 0, false, -1);
            }
        }

        public void Clear()
        {
            for (int i = 0; i < 4; i++)
            {
                CurrentCards[i].card.Reset();
                CurrentCards[i].PlayerId = -1;
            }
        }

        public void SetTeamScores(int index, int value)
        {
            TeamScores[index] = value;
        }

        public int GetTeamScores(int index)
        {
            return TeamScores[index];
        }
    }
}
