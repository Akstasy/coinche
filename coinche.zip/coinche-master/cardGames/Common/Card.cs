﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    public class Card
    {
        public UInt16 Sign { get; private set; }
        public UInt16 Value { get; private set; }
        public bool Playable;

        public void SetSign(UInt16 sign) { Sign = sign; }
        public void SetValue(UInt16 value) { Value = value; }

        public Card(UInt16 sign, UInt16 value, bool playable = false)
        {
            this.Sign = sign;
            this.Value = value;
            this.Playable = playable;
        }

        public void Reset()
        {
            Sign = 0;
            Value = 0;
            Playable = false;
        }
    }
}