﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NetworkCommsDotNet;
using NetworkCommsDotNet.Connections;
using Common;

namespace server
{
    public class Game
    {
        public string RoomHash { get; private set; }
        private List<Player> Players = new List<Player>();
        private string[] SignsName = { "Clubs", "Spades", "Hearts", "Diamonds" }; //♣♠♥♦
        private Bet Bet;
        private UInt16 PassBet, PlayerTurn, Round;
        enum GameMode { initialization, betting, game, score };
        private GameMode Mode = GameMode.initialization;
        private Table MyTable;

        public Game(List<NetworkUser> users)
        {
            Round = 0;
            PassBet = 0;
            PlayerTurn = 0;
            Init(users);
        }

        public void PlayerReady(string message, string identifier)
        {
            foreach (Player player in Players)
            {
                if (player.NetUser.Hash == identifier)
                {
                    player.IsReady = true;
                }
            }
            CheckIfAllReady();
        }

        void CheckIfAllReady()
        {
            int NbReady = 0;

            foreach (Player player in Players)
            {
                if (player.IsReady == true)
                {
                    NbReady++;
                }
            }
            if (NbReady == 4)
            {
                Console.WriteLine("All players are ready\nGame starting: " + RoomHash);
                Mode = GameMode.betting;
                SendBet();
            }
        }

        void SendUserDatas()
        {
            foreach (Player player in Players)
            {
                player.NetUser.ConnectionInfos.SendObject<Player>("Start", player);
            }
        }

        int GetLastIndex(PlayerCard[] cards) {
            int index = 0;

            foreach (PlayerCard playerCard in cards) {
                if (playerCard.PlayerId == -1)
                {
                    break ;
                }
                index++;
            }
            return (index - 1);
        }

        void RemoveCardFromPlayer(Table table)
        {
            int index = GetLastIndex(table.CurrentCards);
            int i = 0;

            Player player = Players.Find(p => (p.Id == table.CurrentPlayerId));
            foreach (Card card in player.Cards)
            {
                if (card.Value == table.CurrentCards[index].card.Value
                    && card.Sign == table.CurrentCards[index].card.Sign)
                {
                    player.Cards[i].Reset();
                    break ;
                }
                i++;
            }
        }

        void SetTableScores(Table table)
        {
            int[] scores = new int[2];

            scores[0] = MyTable.GetTeamScores(0);
            scores[1] = MyTable.GetTeamScores(1);
            MyTable = table;
            MyTable.SetTeamScores(0, scores[0]);
            MyTable.SetTeamScores(1, scores[1]);
        }

        public void ReceiveTable(Table table, string identifier)
        {
            SetTableScores(table);
            RemoveCardFromPlayer(table);
            PlayerTurn++;
            if (PlayerTurn < 4)
            {
                NextGameTurn();
            }
            else
            {
                NextGameRound();
            }
        }

        private void NextGameRound()
        {
            Round++;
            MyTable.CurrentPlayerId = TableWinningCardOwnerId();
            SetTeamsScores();
            ResetTable();
            if (Round < 8)
            {
                PlayerTurn = 0;
                SendScores();
                NextGameTurn();
            }
            else
            {
                Console.WriteLine("Game end: " + RoomHash);
                SendScores();
                SendEnd();
            }
        }

        private void SendEnd()
        {
            foreach (Player player in Players)
            {
                player.NetUser.ConnectionInfos.SendObject<Component<string>>("End", new Component<string>(RoomHash, ""));
            }
        }

        private void SendScores()
        {
            foreach (Player player in Players)
            {
                player.NetUser.ConnectionInfos.SendObject<Component<string>>("Scores", new Component<string>(RoomHash, MyTable.GetTeamScores(0) + " " + MyTable.GetTeamScores(1) + " " + (MyTable.CurrentPlayerId % 2)));
            }
        }

        private void SetTeamsScores()
        {
            int score = MyTable.GetTeamScores(MyTable.CurrentPlayerId % 2);

            foreach (PlayerCard PlayerCard in MyTable.CurrentCards)
            {
                if (PlayerCard.card.Sign == Bet.AtoutSign)
                {
                    score += GetAtoutValue(PlayerCard.card);
                }
                else
                {
                    score += GetNormalValue(PlayerCard.card);
                }
            }
            MyTable.SetTeamScores(MyTable.CurrentPlayerId % 2, score);
        }

        private void ResetTable()
        {
            MyTable.Clear();
        }

        private void NextGameTurn()
        {
            SetCurrentPlayer();
            SendCards(GetPlayerFromId(MyTable.CurrentPlayerId));
            SendTable();
        }

        private void SendBet()
        {
            foreach (Player player in Players)
            {
                player.NetUser.ConnectionInfos.SendObject<Component<Bet>>("Bet", new Component<Bet>(RoomHash, Bet));
            }
        }

        public void ReceivePassBet(string bet, string identifier)
        {
            if (Mode != GameMode.betting || identifier != GetIdentifierFromId(Bet.CurrentPlayerId))
            {
                DisconnectAll("cheater");
            }
            PassBet += 1;
            ReceiveBet(bet, false, identifier);
        }

        public void ReceiveBet(string bet, bool valueBet, string identifier)
        {
            if (Mode != GameMode.betting)
            {
                DisconnectAll("cheater");
            }
            if (valueBet == true)
            {
                if (Bet.BetValue < UInt16.Parse(bet.Split('/').Last()))
                {
                    PassBet = 0;
                    Bet.AtoutSign = UInt16.Parse(bet.Split('/').First());
                    Bet.BetValue = UInt16.Parse(bet.Split('/').Last());
                    Bet.PlayerId = Bet.CurrentPlayerId;
                }
                else
                {
                    DisconnectAll("cheater");
                }
            }
            CheckBetPhase();
            SendBet();
        }

        private void CheckBetPhase()
        {
            if (PassBet == 3)
            {
                PassBet = 0;
                if (Bet.BetValue != 0)
                {
                    Bet.CurrentPlayerId = 5;
                    Mode = GameMode.game;
                    StartGame();
                    return;
                }
            } else
            {
                SetCurrentPlayer();
            }
        }

        private void SetCurrentPlayer()
        {
            if (Mode == GameMode.betting)
            {
                Bet.CurrentPlayerId = (UInt16)(((int)Bet.CurrentPlayerId + 1) % 5);
                Bet.CurrentPlayerId = Bet.CurrentPlayerId == 0 ? (UInt16)1 : Bet.CurrentPlayerId;
            }
            else if (Mode == GameMode.game)
            {
                MyTable.CurrentPlayerId = (UInt16)(((int)MyTable.CurrentPlayerId + 1) % 5);
                MyTable.CurrentPlayerId = MyTable.CurrentPlayerId == 0 ? (UInt16)1 : MyTable.CurrentPlayerId;
            }
        }

        private void StartGame()
        {
            MyTable = new Table(Bet.CurrentPlayerId);
            SetCurrentPlayer();
            SendTurn();
        }

        private void SendTurn()
        {
            foreach (Player player in Players)
            {
                if (player.Id == MyTable.CurrentPlayerId)
                {
                    SendCards(player);
                }
            }
            SendTable();
        }

        private void SendTable()
        {
            foreach (Player player in Players)
            {
                player.NetUser.ConnectionInfos.SendObject<Component<Table>>("Game", new Component<Table>(player.RoomHash, MyTable));
            }
        }

        bool CheckHasPlayable(Player player)
        {
            int countPlayable = 0;
            foreach (Card card in player.Cards)
            {
                if (card.Value == 0) { continue; }
                if (card.Playable == true)
                {
                    countPlayable++;
                }
            }
            return (countPlayable != 0);
        }

        private int IsRightSign(Player player)
        {
            int count = 0;
            
            foreach (Card card in player.Cards)
            {
                if (card.Value == 0) { continue; }
                if (card.Sign == MyTable.CurrentCards[0].card.Sign)
                {
                    card.Playable = true;
                    count++;
                }
                else
                {
                    card.Playable = false;
                }
            }
            return (count);
        }

        private int CountCard(PlayerCard[] cards)
        {
            int count = 0;
            for (int i = 0; i < 4; i++)
            {
                if (cards[i].PlayerId != -1)
                {
                    count++;
                }
            }
            return (count);
        }

        private void SetPlayableCards(Player player)
        {
            if (CountCard(MyTable.CurrentCards) == 0)
            {
                SetAllCardsState(player, true);
                return ;
            }

            int count = IsRightSign(player);

            if (count == 0 && (IsAlly(TableWinningCardOwnerId()) == true
                || SetAtoutCards(player) == 0))
            {
                SetAllCardsState(player, true);
            }
        }

        private bool IsAlly(int PlayerId)
        {
            return (PlayerId % 2 == MyTable.CurrentPlayerId % 2);
        }

        private int TableWinningCardOwnerId()
        {
            int identifier;
            bool hasAtout = false;

            foreach (PlayerCard TablePlayerCard in MyTable.CurrentCards)
            {
                if (TablePlayerCard.PlayerId == -1)
                {
                    continue ;
                }
                if (TablePlayerCard.card.Sign == Bet.AtoutSign)
                {
                    hasAtout = true;
                    break ;
                }
            }
            if (hasAtout == true)
            {
                identifier = CompareAtoutCards();
            }
            else
            {
                identifier = CompareNormalCards();
            }
            return (identifier);
        }

        private string GetIdentifierFromId(int id)
        {
            foreach (Player player in Players)
            {
                if (player.Id == id)
                {
                    return player.NetUser.Hash;
                }
            }
            return (null);
        }

        private Player GetPlayerFromId(int id)
        {
            foreach (Player player in Players)
            {
                if (player.Id == id)
                {
                    return player;
                }
            }
            return (null);
        }

        private int GetIdFromIdentifier(string identifier)
        {
            foreach (Player player in Players)
            {
                if (player.NetUser.Hash == identifier)
                {
                    return player.Id;
                }
            }
            return (0);
        }

        Dictionary<UInt16, UInt16> AtoutCards = new Dictionary<UInt16, UInt16>()
        {
            {7, 0}, {8, 0}, {9, 14}, {11, 20}, {12, 3}, {13, 4}, {10, 10}, {14, 11}
        };

        private UInt16 GetAtoutValue(Card card)
        {
            return (AtoutCards[card.Value] == 0 ? (UInt16)(card.Value == 7 ? 0 : 1) : (UInt16)AtoutCards[card.Value]);
        }

        private int CompareAtoutCards()
        {
            int id = -1;
            Card myCard = null;

            foreach (PlayerCard TablePlayerCard in MyTable.CurrentCards)
            {
                if (TablePlayerCard.PlayerId == -1)
                {
                    break;
                }
                if (myCard == null
                    || GetAtoutValue(TablePlayerCard.card) > GetAtoutValue(myCard))
                {
                    myCard = TablePlayerCard.card;
                    id = TablePlayerCard.PlayerId;
                }
            }
            return (id);
        }

        Dictionary<UInt16, UInt16> NonAtoutCards = new Dictionary<UInt16, UInt16>()
        {
            {7, 0}, {8, 0}, {9, 1}, {11, 2}, {12, 3}, {13, 4}, {10, 10}, {14, 11} // for score count: if value == 1 TrueValue = 0
        };

        private int GetNormalValue(Card card)
        {
            return (NonAtoutCards[card.Value] == 0 ? (UInt16)(card.Value == 7 ? 0 : 1) : (UInt16)NonAtoutCards[card.Value]);
        }

        private int CompareNormalCards()
        {
            int id = -1;
            Card myCard = null;

            foreach (PlayerCard TablePlayerCard in MyTable.CurrentCards)
            {
                if (TablePlayerCard.PlayerId == -1)
                {
                    continue ;
                }
                if (myCard == null
                    || (GetNormalValue(TablePlayerCard.card) > GetNormalValue(myCard)))
                {
                    if (TablePlayerCard.card.Value == 8 && myCard != null && myCard.Value == 9) { continue; }
                    myCard = TablePlayerCard.card;
                    id = TablePlayerCard.PlayerId;
                }
            }
            return (id);
        }

        private int SetAtoutCards(Player player)
        {
            int count = 0;
            
            if (CheckHasPlayable(player) == false)
            {
                foreach (Card card in player.Cards)
                {
                    if (card.Value == 0) { continue; }
                    if (card.Sign == Bet.AtoutSign)
                    {
                        card.Playable = true;
                        count++;
                    }
                }
            }
            return (count);
        }

        private void SetAllCardsState(Player player, bool state)
        {
            foreach (Card card in player.Cards)
            {
                card.Playable = state;
            }
        }

        private void SendCards(Player player)
        {
            SetPlayableCards(player);
            player.NetUser.ConnectionInfos.SendObject<Component<Player>>("Cards", new Component<Player>(player.RoomHash, player));
        }

        private void InitBet()
        {
            Bet = new Bet(Players[0].Id);
        }

        public void Start()
        {
            InitBet();
            SendUserDatas();
        }

        public void ReceiveCoinche(string message, string identifier)
        {
            Bet.Coinche = true;
            Bet.CurrentPlayerId = Bet.PlayerId;
            Player player = GetPlayerFromId(Bet.PlayerId);
            player.NetUser.ConnectionInfos.SendObject<Component<Bet>>("Coinche", new Component<Bet>(player.RoomHash, Bet));
        }

        public void ReceiveSurCoinche(string message, string identifier)
        {
            PassBet = 3;
            if (message == "surcoinche")
            {
                Bet.Multiplier = 4;
            }
            else if (message != "pass")
            {
                Bet.Multiplier = 2;
                DisconnectAll();
                return ;
            }
            CheckBetPhase();
        }

        private void Init(List<NetworkUser> users)
        {
            List<Card> deck = CreateShuffledDeck();
            string roomHash = $"{users[0].Hash}:{users[1].Hash}:{users[2].Hash}:{users[3].Hash}";

            RoomHash = roomHash;
            for (int i = 0; i < 4; i++)
            {
                int id = i + 1;
                int groupId = i % 2;
                List<Card> userDeck = new List<Card>();
                for (int j = 0; j < 8; j++)
                {
                    userDeck.Add(deck[0]);
                    deck.RemoveAt(0);
                }
                Player player = new Player((UInt16)id, (UInt16)groupId, roomHash, userDeck);
                player.SetNetworkUser(users[i]);
                Players.Add(player);
            }
        }

        private static List<Card> CreateShuffledDeck()
        {
            List<Card> deck = new List<Card>();

            for (UInt16 i = 0; i < 4; i++)
            {
                for (UInt16 j = 7; j <= 14; j++)
                {
                    deck.Add(new Card(i, j));
                }
            }
            Random rng = new Random();
            int n = deck.Count;
            while (n > 1)
            {
                n--;
                int k = rng.Next(n + 1);
                Card value = deck[k];
                deck[k] = deck[n];
                deck[n] = value;
            }

            return deck;
        }

        public void DisconnectAll(string excludedIdentifier = "none", string mode = "normal")
        {
            foreach (Player player in Players)
            {
                if (player.NetUser.Hash != excludedIdentifier)
                {
                    player.NetUser.ConnectionInfos.SendObject<string>("500", mode == "cheater" ?
                       "room closed, there is a cheater in this room" : "a player has been disconnected from the room");
                }
            }
            
            for (int i = 0; i < Players.Count(); i++)
            {
                RemovePlayer(Players[0].NetUser.Hash);
            }
        }

        public void RemovePlayer(string identifier)
        {
            int i = 0;
            foreach (Player player in Players)
            {
                if (player.NetUser.Hash == identifier)
                {
                    Console.WriteLine("Player " + player.NetUser.Hash + " removed from lists");
                    break ;
                }
                i++;
            }
            if (i < Players.Count())
            {
                Players.RemoveAt(i);
            }
        }
    }
}
