﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using Common;
using NetworkCommsDotNet;
using NetworkCommsDotNet.Connections;

namespace server
{
    class Server
    {
        private UInt16 MaxClient;
        private List<NetworkUser> NetworkUsers = new List<NetworkUser>();
        private Dictionary<string, Game> Games = new Dictionary<string, Game>();

        /// <summary>
        /// Server constructor with callbacks initialisation, connection activation and port + ip listing
        /// </summary>
        public Server(UInt16 port, UInt16 maxClient = 40)
        {
            MaxClient = maxClient;
            NetworkComms.AppendGlobalConnectionEstablishHandler(ConnectionHandler);
            NetworkComms.AppendGlobalConnectionCloseHandler(DisconnectionHandler);//to implem
            NetworkComms.AppendGlobalIncomingUnmanagedPacketHandler(UnknownHandler);

            NetworkComms.AppendGlobalIncomingPacketHandler<Component<string>>("Bet", ReceiveBet);
            NetworkComms.AppendGlobalIncomingPacketHandler<Component<string>>("PassBet", ReceivePassBet);
            NetworkComms.AppendGlobalIncomingPacketHandler<Component<string>>("Ready", SetPlayerReady);
            NetworkComms.AppendGlobalIncomingPacketHandler<Component<string>>("Coinche", ReceiveCoinche);
            NetworkComms.AppendGlobalIncomingPacketHandler<Component<string>>("Surcoinche", ReceiveSurCoinche);
            NetworkComms.AppendGlobalIncomingPacketHandler<Component<Table>>("Table", ReceiveTable);

            Connection.StartListening(ConnectionType.TCP, new System.Net.IPEndPoint(System.Net.IPAddress.Any, port));

            foreach (System.Net.IPEndPoint localEndPoint in Connection.ExistingLocalListenEndPoints(ConnectionType.TCP))
            {
                Console.WriteLine("{0}:{1}", localEndPoint.Address, localEndPoint.Port);
            }
        }

        private void ReceiveTable(PacketHeader packetHeader, Connection connection, Component<Table> comp)
        {
            Games[comp.RoomHash].ReceiveTable(comp.Object, connection.ConnectionInfo.NetworkIdentifier);
        }

        private void ReceiveCoinche(PacketHeader packetHeader, Connection connection, Component<string> comp)
        {
            Games[comp.RoomHash].ReceiveCoinche(comp.Object, connection.ConnectionInfo.NetworkIdentifier);
        }

        private void ReceiveSurCoinche(PacketHeader packetHeader, Connection connection, Component<string> comp)
        {
            Games[comp.RoomHash].ReceiveSurCoinche(comp.Object, connection.ConnectionInfo.NetworkIdentifier);
        }

        /// <summary>
        /// Function called when a player pass his turn
        /// <param PacketHeader="packetHeader">no description needed</param>
        /// <param Connection="connection">object containing user infos</param>
        /// <param Component<string>="comp">Component is an object that possess a header with room name and the sent object</param>
        /// </summary>
        private void ReceivePassBet(PacketHeader packetHeader, Connection connection, Component<string> comp)
        {
            Games[comp.RoomHash].ReceivePassBet(comp.Object, connection.ConnectionInfo.NetworkIdentifier);
        }

        private object synlock = new object();

        /// <summary>
        /// Function called when a player game is started and ready
        /// <param PacketHeader="packetHeader">no description needed</param>
        /// <param Connection="connection">object containing user infos</param>
        /// <param Component<string>="comp">Component is an object that possess a header with room name and the sent object</param>
        /// </summary>
        private void SetPlayerReady(PacketHeader packetHeader, Connection connection, Component<string> comp)
        {
            lock (synlock)
            {
                Games[comp.RoomHash].PlayerReady(comp.Object, connection.ConnectionInfo.NetworkIdentifier);
            }
        }

        /// <summary>
        /// Basic function for server to stay actif
        /// </summary>
        public void Start()
        {
            while (true)
            {
                Thread.Sleep(5000);
            }
        }

        /// <summary>
        /// Function called when a player join the server
        /// <param Connection="connection">object containing user infos</param>
        /// </summary>
        private void ConnectionHandler(Connection connection)
        {
            Console.WriteLine("New connection {0}", NetworkComms.TotalNumConnections());
            if (NetworkComms.TotalNumConnections() > MaxClient)
            {
                Console.WriteLine("Warning: Connection refused due to server full");
                connection.SendObject("500");
                connection.CloseConnection(false);
            }
            else
            {
                NetworkUsers.Add(GetNetworkUser(connection));
                connection.SendObject("200");

                if (NetworkUsers.Count % 4 == 0)
                {
                    List<NetworkUser> localUsers = new List<NetworkUser>();

                    for (int i = 0; i < 4; i++)
                    {
                        localUsers.Add(NetworkUsers[0]);
                        NetworkUsers.RemoveAt(0);
                    }
                    var game = new Game(localUsers);
                    Console.WriteLine("New game started in room " + game.RoomHash);
                    Games[game.RoomHash] = game;
                    game.Start();
                }
            }
        }

        /// <summary>
        /// Function called when an unknown packet is received
        /// </summary>
        private void UnknownHandler(PacketHeader packetHeader, Connection connection, byte[] message)
        {
            Console.WriteLine("Unknown packet received: " + message);
        }

        /// <summary>
        /// Function called when a player leave the server
        /// <param Connection="connection">object containing user infos</param>
        /// </summary>
        private void DisconnectionHandler(Connection connection)
        {
            foreach (KeyValuePair<string, Game> game in Games)
            {
                if (game.Key.Contains(connection.ConnectionInfo.NetworkIdentifier) == true)
                {
                    Console.WriteLine("Player " + connection.ConnectionInfo.NetworkIdentifier + " has disconnected from room " + Games[game.Key].RoomHash);
                    Games[game.Key].RemovePlayer(connection.ConnectionInfo.NetworkIdentifier);
                    Games[game.Key].DisconnectAll(connection.ConnectionInfo.NetworkIdentifier);
                    return;
                }
            }
            RemoveNetUser(connection);
            Console.WriteLine("A client has disconnected from the server");
        }

        private void RemoveNetUser(Connection connection)
        {
            int i = 0;
            foreach (NetworkUser user in NetworkUsers)
            {
                if (user.Hash == connection.ConnectionInfo.NetworkIdentifier)
                {
                    Console.WriteLine("user removed from waiting list");
                    NetworkUsers.RemoveAt(i);
                    return;
                }
                ++i;
            }
        }

        /// <summary>
        /// Function called when an user join the server to create a new user
        /// <param Connection="connection">object containing user infos</param>
        /// </summary>
        private static NetworkUser GetNetworkUser(Connection connection)
        { 
            var endPoint = connection.ConnectionInfo.RemoteEndPoint.ToString();
            string ip = endPoint.Substring(0, endPoint.LastIndexOf(":"));
            UInt16 port = UInt16.Parse(endPoint.Split(':').Last());
            string hash = connection.ConnectionInfo.NetworkIdentifier;

            return new NetworkUser(connection, ip, port, hash);
        }

        /// <summary>
        /// Function called when a player send a bet
        /// <param PacketHeader="packetHeader">no description needed</param>
        /// <param Connection="connection">object containing user infos</param>
        /// <param Component<string>="comp">Component is an object that possess a header with room name and the sent object</param>
        /// </summary>
        private void ReceiveBet(PacketHeader header, Connection connection, Component<string> comp)
        {
            Games[comp.RoomHash].ReceiveBet(comp.Object, true, connection.ConnectionInfo.NetworkIdentifier);
        }
    }
}
