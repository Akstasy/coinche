To launch a game you have to settup the server by chosing a port (UInt16)

Then every 4 connection a room will be setup to host a party

Initialisation:
To connect to the server you have to enter the ip and port separated by ':'
The game start when every 4 players of the room have received their deck.

Betting phase:
First, the server will chose a player to start betting.
The chosen player will see his deck and will have to chose a couple signe/value for the bet.
This couple define the trump and the score to reach by the end of the game in order to win the bet.
Every players will have to chose turn by turn their bet, they also have the possibility to pass their turn or to coinche an enemy's bet.
If an enemy use a coinche against your bet (first of all the bet is doubled), you have to answer by: pass or surcoinche,
if you chose to surcoinche the bet is set to 4 times the initial value. This answer put an end to the betting phase.

Game phase:
During the game phase every players'll chose their cards according to the one on the table (except for the first play which is free).
The game automaticaly show which card is allowed to be played on the current turn.
Every round (when the 4 players have played) the scores are set and the table is cleaned for the new one.
A game is divided in 8 rounds, each divided in 4 turns. At the end of the game the scores are set and the winner of the bet is selected